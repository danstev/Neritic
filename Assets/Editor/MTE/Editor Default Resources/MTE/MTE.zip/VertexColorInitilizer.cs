﻿/*
 * Those cs file is already compiled into a dll here: Assets\Plugins\MTE\MTE_script.dll. So don't extract them into your project directory.
 * This is provided to allow you to modify it and compile it into MTE_script.dll. And then replace the orginal one.
 */
using UnityEngine;

#if UNITY_EDITOR
//Please keep this attribute, it is used by MTE editor.
[ExecuteInEditMode]
#endif
public class VertexColorInitilizer : MonoBehaviour
{
    public VertexColor vertexColor = null;

    void Start()
    {
        ApplyVertexColor();
    }

    /// <summary>
    /// Apply the vertex colors in the VertexColor asset file to the mesh
    /// </summary>
    /// <remarks>
    /// Please keep this method public, because MTE will call this method to apply vertex color in editor.
    /// </remarks>
    public void ApplyVertexColor()
    {
        var meshCollider = GetComponent<MeshCollider>();
        if(meshCollider.sharedMesh != null && vertexColor != null && vertexColor.colors != null &&
           vertexColor.colors.Length != 0)
        {
            if(meshCollider.sharedMesh.colors != vertexColor.colors)
            {
                meshCollider.sharedMesh.colors = vertexColor.colors;
            }
        }
    }
}
